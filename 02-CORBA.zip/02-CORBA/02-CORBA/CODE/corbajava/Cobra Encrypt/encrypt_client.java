// encrypt_client.java

import encrypt_val.*;
import org.omg.CosNaming.*;
import org.omg.CosNaming.NamingContextPackage.*;
import org.omg.CORBA.*;
import java.io.*;
import java.lang.*;
public class encrypt_client
{
    static encrypt encryptimpl;
    public static void main(String args[])
    {
      try
      {

        String result_str,tempstr;
        ORB orb=ORB.init(args,null);
        org.omg.CORBA.Object objref=orb.resolve_initial_references(\"NameService\");

        NamingContextExt ncref=NamingContextExtHelper.narrow(objref);

        String pathname=\"encrypt\";
        encryptimpl=encryptHelper.narrow(ncref.resolve_str(pathname));

        BufferedReader in=new BufferedReader(new InputStreamReader(System.in));

        System.out.println(\"Enter string you want to send to server : \");
        tempstr=in.readLine();
        StringBuffer string1=new StringBuffer(tempstr);
    for(int i=0;i<string1.length();i++)
        {
          string1.setCharAt(i,(char)(string1.charAt(i)+2));
        }
        System.out.println(\"Encrypted string sent to server : \"+string1);

        result_str=encryptimpl.getstr(string1.toString());

        System.out.println(\"Decrypted string recvd from server is as below:\");
        System.out.println(result_str);

      }
      catch(Exception e)
      {
         System.out.println(e);
      }
    }

}

