// encrypt_server.java

import encrypt_val.*;
import org.omg.CosNaming.*;
import org.omg.CosNaming.NamingContextPackage.*;
import org.omg.CORBA.*;
import org.omg.PortableServer.*;
import org.omg.PortableServer.POA;
import java.lang.*;
import java.util.*;
import java.text.*;
class serverimpl extends encryptPOA
{
   private ORB orb;
   public void setorb(ORB orb_val)
   {
      orb=orb_val;
   }

   public String getstr(String str1)
   {
     StringBuffer strb1=new StringBuffer(str1);
     Date dateobj=new Date();
     SimpleDateFormat sdf;
     sdf=new SimpleDateFormat(\"hh:mm:ss\");

     String datestr=sdf.format(dateobj).toString();
     datestr=\" \"+datestr+\" \";

     for(int i=0;i<strb1.length();i++)
        {
          strb1.setCharAt(i,(char)(strb1.charAt(i)-2));
          if(strb1.charAt(i)==\' \')
            {
             strb1.insert(i,datestr);
             i=i+datestr.length();
            }
       }
     return(strb1.toString());
   }
}
public class encrypt_server
{
   public static void main(String args[])
   {
     try
     {
         ORB orb=ORB.init(args,null);

         org.omg.CORBA.Object objref1=orb.resolve_initial_references(\"RootPOA\");
         POA rootpoa=POAHelper.narrow(objref1);
         rootpoa.the_POAManager().activate();

         serverimpl serverobj=new serverimpl();
         serverobj.setorb(orb);
         org.omg.CORBA.Object objref2=rootpoa.servant_to_reference(serverobj);
         encrypt href=encryptHelper.narrow(objref2);

         org.omg.CORBA.Object objref3= orb.resolve_initial_references(\"NameService\");
         NamingContextExt ncref=NamingContextExtHelper.narrow(objref3);
         String pathname=\"encrypt\";
         NameComponent path[]=ncref.to_name(pathname);
         ncref.rebind(path,href);


         System.out.println(\"server ready and waiting...\");

         orb.run();

     }
     catch(Exception e)
     {
       System.out.println(e);
     }
   }


}
