import HelloApp.*;          // The package containing our stubs
import org.omg.CosNaming.*; // HelloClient will use the naming service.
import org.omg.CosNaming.NamingContextPackage.*;
import org.omg.CORBA.*;     // All CORBA applications need these classes.

public class HelloClient
{
    static Hello helloImpl;
    
    public static void main(String args[])
    {
	try {
	    ORB orb = ORB.init(args, null);
	    org.omg.CORBA.Object objRef = 
                     orb.resolve_initial_references("NameService");
	    NamingContextExt ncRef = NamingContextExtHelper.narrow(objRef);

	    String name = "Hello";
	    helloImpl = HelloHelper.narrow(ncRef.resolve_str(name));


	    while (true) { 
		System.out.println(helloImpl.sayHello());

		System.out.println("Rest for 6 seconds before calling the server again...\n");
		System.out.println("...if the server is down it will be automatically restarted...\n");
		Thread.sleep(6000);
	    }

	} catch(Exception e){
	    System.out.println("ERROR : " + e);
	    e.printStackTrace(System.out);
	}
    }
}
