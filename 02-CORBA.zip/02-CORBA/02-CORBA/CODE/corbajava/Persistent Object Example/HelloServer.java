import HelloApp.*;          // The package containing our stubs. 
import org.omg.CosNaming.*; // HelloServer will use the naming service. 
import org.omg.CosNaming.NamingContextPackage.*; // ..for exceptions. 
import org.omg.CORBA.*;     // All CORBA applications need these classes. 
import org.omg.PortableServer.*;   
import org.omg.PortableServer.POA;

public class HelloServer 
{
    public static void main(String args[]) 
    {
	try { 
	    //create and initialise the ORB
	    ORB orb = ORB.init(args, null); 

	    //create servant and instantiate it
	    HelloServant servant = new HelloServant(orb);

	    //get reference to rootpoa and active the POAManager
	    POA rootpoa = POAHelper.narrow(orb.resolve_initial_references("RootPOA"));  
	    //rootpoa.the_POAManager().activate(); 

	    //Create the Persistent Policy
	    Policy[] policy = new Policy[1];
	    policy[0] = rootpoa.create_lifespan_policy(LifespanPolicyValue.PERSISTENT);

	    //Create the persistent POA by passing the policy
	    POA poa = rootpoa.create_POA("childPOA", null, policy);

	    //Activate the child POA's POAManager: without this all calls
	    //to the persitent server will hang because the POAManager will
            //be in the HOLD state.
	    poa.the_POAManager().activate();

	    //Associate the servant with the persistent POA
	    poa.activate_object(servant);

	    // Resolve RootNaming context
	    org.omg.CORBA.Object objRef = 
		           orb.resolve_initial_references("NameService");
	    NamingContextExt ncRef = NamingContextExtHelper.narrow(objRef);

	    //Bind the object reference in the naming context
	    NameComponent path[] = ncRef.to_name("Hello");
	    ncRef.rebind(path, poa.servant_to_reference(servant));

	    //wait for client requests
	    orb.run();
	}
	    
	catch(Exception e) {
	    System.err.println("ERROR : " + e);
	    e.printStackTrace(System.out);
	}
    }
}
