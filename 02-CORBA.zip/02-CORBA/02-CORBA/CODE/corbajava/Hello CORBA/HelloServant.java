import HelloApp.*;          // The package containing our stubs.
import org.omg.CORBA.*;     // All CORBA applications need these classes.
import org.omg.PortableServer.*;
import org.omg.PortableServer.POA;

class HelloServant extends HelloBasic implements HelloOperations
{
    private ORB orb;

    public void setORB(ORB orb_val) {
	orb = orb_val;
    }

    public void shutdown() {
	orb.shutdown(false);
    }
}


class HelloBasic {
    public String sayHello() {
	return "\nHello world!!\n";
    }
}
