import MemoApp.*;
import org.omg.CosNaming.*;
import org.omg.CosNaming.NamingContextPackage.*;
import org.omg.CORBA.*;
import org.omg.PortableServer.*;
import org.omg.PortableServer.POA;
import java.io.*;
 
// class Test {
//     public static void main (String[] args) {
// 	try {
// 	    FileOutputStream fs = new FileOutputStream("test.dat");
// 	    PrintWriter ps = new PrintWriter(fs);
// 	    ps.println("This is a test.");
// 	    ps.close();
// 	} catch (FileNotFoundException fnfe) {
// 	    System.err.println("Could not open file.");
// 	}
//     }
// }

class MemoServant extends MemoPOA
{
    public String saveMemo(String msg)
        throws MemoApp.MemoPackage.cantWriteFile
    {
        try {
	    synchronized(this) {
		FileOutputStream fos = 
		    new FileOutputStream("memoStorage.txt");
		PrintWriter pw = new PrintWriter(fos);
		pw.print(msg);
		pw.close();
	    }
        } catch(FileNotFoundException e) {
	    System.err.println("Could not open file.");
	    throw new MemoApp.MemoPackage.cantWriteFile();
        }
        return "\n Your memo has been recorded \n";
    }
    
    public String lastMemo()
        throws MemoApp.MemoPackage.cantReadFile
    {
        try {
	    synchronized(this) {
		File memoFile = new File("memoStorage.txt");
		FileInputStream fis = new FileInputStream(memoFile);
		byte[] buf = new byte[1000];
		int n = fis.read(buf);
		String lastmsg = new String(buf);
		fis.close();
		return lastmsg;
	    }
        } catch(Exception e) {
	    throw new MemoApp.MemoPackage.cantReadFile();
        }
    }
}

 
public class MemoServer {
 
    public static void main(String args[])
    {
        try{
	    ORB orb = ORB.init(args, null);
	    
            POA rootpoa = POAHelper.narrow(orb.resolve_initial_references("RootPOA"));
            rootpoa.the_POAManager().activate();
 
            MemoServant memoImpl = new MemoServant();
 
            org.omg.CORBA.Object ref = rootpoa.servant_to_reference(memoImpl);
            Memo mref = MemoHelper.narrow(ref);
 
            org.omg.CORBA.Object objRef =
                           orb.resolve_initial_references("NameService");
            NamingContextExt ncRef = NamingContextExtHelper.narrow(objRef);
 
            String name = "Memo";
            NameComponent path[] = ncRef.to_name(name);
            ncRef.rebind(path, mref);
 
            orb.run();
           
        } catch (Exception e) {
            System.err.println("ERROR: " + e);
            e.printStackTrace(System.out);
        }
    }
}
 
