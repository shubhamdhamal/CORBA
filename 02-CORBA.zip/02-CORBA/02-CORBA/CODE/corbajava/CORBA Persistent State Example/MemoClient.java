import MemoApp.*;
import org.omg.CosNaming.*;
import org.omg.CORBA.*;
 
public class MemoClient 
{    
    static Memo memoImpl;

    public static void main(String args[])
    {
        try{
	    ORB orb = ORB.init(args, null);
            org.omg.CORBA.Object objRef =
                     orb.resolve_initial_references("NameService");
            NamingContextExt ncRef = NamingContextExtHelper.narrow(objRef);
 
            String name = "Memo";
            memoImpl = MemoHelper.narrow(ncRef.resolve_str(name));

            // call the Memo server object and print results
        
            String oldmemo = memoImpl.lastMemo();
            System.out.println("\n "+oldmemo+" \n");
            String memo = memoImpl.saveMemo(args[0]);
            System.out.println(memo);
 
        } catch (Exception e) {
            System.out.println("ERROR : " + e) ;
            e.printStackTrace(System.out);
        }
    }
}

