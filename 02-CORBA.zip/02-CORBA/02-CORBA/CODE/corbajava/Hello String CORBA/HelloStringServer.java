import HelloApp.*;          // The package containing our stubs. 
import org.omg.CosNaming.*; // HelloServer will use the naming service. 
import org.omg.CosNaming.NamingContextPackage.*; // ..for exceptions. 
import org.omg.CORBA.*;     // All CORBA applications need these classes. 

public class HelloStringServer 
{
    public static void main(String args[]) 
    {
	try { 
	    ORB orb = ORB.init(args, null); 

	    POA rootpoa = POAHelper.narrow(orb.resolve_initial_references("RootPOA"));  
	    rootpoa.the_POAManager().activate(); 

	    HelloServant helloImpl = new HelloServant();
	    helloImpl.setORB(orb); 

	    // create the object reference
	    org.omg.CORBA.Object obj = rootpoa.servant_to_reference(helloImpl);

	    //print stringified object reference
	    System.out.println(orb.object_to_string(obj));                                                             
	    
	    orb.run();
	}
	    
	catch(Exception e) {
	    System.err.println("ERROR : " + e);
	    e.printStackTrace(System.out);
	}
    }
}
