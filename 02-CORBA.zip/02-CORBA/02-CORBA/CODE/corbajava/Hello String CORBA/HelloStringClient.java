import HelloApp.*;          // The package containing our stubs
import org.omg.CosNaming.*; // HelloClient will use the naming service.
import org.omg.CosNaming.NamingContextPackage.*;
import org.omg.CORBA.*;     // All CORBA applications need these classes.

public class HelloStringClient
{
    static Hello helloImpl;
    
    public static void main(String args[])
    {
	try {
	    ORB orb = ORB.init(args, null);
	    org.omg.CORBA.Object obj = orb.string_to_object(args[0]);
	    Hello helloImpl =  HelloHelper.narrow(obj);
 
	    if (helloImpl == null) {
                System.err.println("error in stringified object reference");
                System.exit(-1);
            }

	    System.out.println(helloImpl.sayHello());
	    helloImpl.shutdown();

	} catch(Exception e){
	    System.out.println("ERROR : " + e);
	    e.printStackTrace(System.out);
	}
    }
}
