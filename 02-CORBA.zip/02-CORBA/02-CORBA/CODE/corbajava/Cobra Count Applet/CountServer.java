// CountServer.java: The Count Server main program

import Counter.*;
import org.omg.CosNaming.*;
import org.omg.CosNaming.NamingContextPackage.*;
import org.omg.CORBA.*;
import org.omg.PortableServer.*;

class CountServer
{ staticpublicvoid main(String[] args)
  { try
    { // Initialize the ORB
      org.omg.CORBA.ORB orb = org.omg.CORBA.ORB.init(args, null);

      // Initialize the BOA
      POA rootpoa = POAHelper.narrow(orb.resolve_initial_references("RootPOA"));
      rootpoa.the_POAManager().activate();

      // Create the Count object
      CountImpl count = new CountImpl("My Count");

      // get object reference from the servant
      org.omg.CORBA.Object ref = rootpoa.servant_to_reference(count);
      Count href = Counter.CountHelper.narrow(ref);
      
      // get the root naming context// NameService invokes the name service
      org.omg.CORBA.Object objRef =
          orb.resolve_initial_references("NameService");
      // Use NamingContextExt which is part of the Interoperable// Naming Service (INS) specification.
      NamingContextExt ncRef = NamingContextExtHelper.narrow(objRef);

      // bind the Object Reference in Naming
      String name = "Count";
      NameComponent path[] = ncRef.to_name( name );
      ncRef.rebind(path, href);

      System.out.println("HelloServer ready and waiting ...");

      // wait for invocations from clients
      orb.run();

      }
      catch(Exception e)
      { System.err.println(e);
      }
   }
}
