// CountClientApplet.java  Applet Client, VisiBroker for Java

import Counter.*;
import org.omg.CosNaming.*;
import org.omg.CosNaming.NamingContextPackage.*;
import org.omg.CORBA.*;
import java.awt.*;

publicclass CountClientApplet extends java.applet.Applet
{ private TextField countField, pingTimeField;
  private Button runCount;
  private Counter.Count counter;
  publicvoid init()
  { // Create a 2 by 2 grid of widgets.
    setLayout(new GridLayout(2, 2, 10, 10));

    // Add the four widgets, initialize where necessary
    add(new Label("Count"));
    add(countField = new TextField());
    countField.setText("1000");
    add(runCount = new Button("Run"));
    add(pingTimeField = new TextField());
    pingTimeField.setEditable(false);

    try
    { // Initialize the ORB.
      showStatus("Initializing the ORB");
      org.omg.CORBA.ORB orb = org.omg.CORBA.ORB.init(this, null);

      // Bind to the Count Object// get the root naming context
        org.omg.CORBA.Object objRef = 
        orb.resolve_initial_references("NameService");
        // Use NamingContextExt instead of NamingContext. This is // part of the Interoperable naming Service.  
        NamingContextExt ncRef = NamingContextExtHelper.narrow(objRef);
 
        // resolve the Object Reference in Naming
        String name = "Count";
        counter = CountHelper.narrow(ncRef.resolve_str(name));

      showStatus("Binding to Count Object");

    } catch(Exception e)
    {
      showStatus("Applet Exception" + e);
      e.printStackTrace(System.out);
    }
  }

  public boolean action(Event ev, java.lang.Object arg)
  { if(ev.target == runCount)
    { try
      { // Set Sum to initial value of 0
        showStatus("Setting Sum to 0");
        counter.sum((int)0);

        // get data from and set value of applet fields
        showStatus("Incrementing");
        int stopCount = Integer.parseInt(countField.getText());
        pingTimeField.setText(" ");

        // Calculate Start timelong startTime = System.currentTimeMillis();

        // Increment stopCount timesfor (int i = 0 ; i < stopCount ; i++ )
        { counter.increment();
        }

        // Calculate stop time; show statisticslong stopTime = System.currentTimeMillis();
        pingTimeField.setText("Avg Ping = "
                  + Float.toString((float)(stopTime- startTime)/stopCount)
                  + " msecs");
        showStatus("Sum = " + counter.sum());
      } catch(Exception e)
      { showStatus("System Exception" + e);
      e.printStackTrace();
      }
      returntrue;
    }
    returnfalse;
  }
}