// CountClient.java  

import Counter.*;
import org.omg.CosNaming.*;
import org.omg.CosNaming.NamingContextPackage.*;
import org.omg.CORBA.*;

class CountClient { 

  static Count countImpl;

  publicstaticvoid main(String args[])
  { try
    { // Initialize the ORB
      System.out.println("Initializing the ORB");
      org.omg.CORBA.ORB orb = org.omg.CORBA.ORB.init(args, null);

        // get the root naming context
        org.omg.CORBA.Object objRef = 
        orb.resolve_initial_references("NameService");
        // Use NamingContextExt instead of NamingContext. This is // part of the Interoperable naming Service.  
        NamingContextExt ncRef = NamingContextExtHelper.narrow(objRef);
 
        // resolve the Object Reference in Naming
        String name = "Count";
        countImpl = CountHelper.narrow(ncRef.resolve_str(name));

        System.out.println("Obtained a handle on server object: " + countImpl);

      // Set sum to initial value of 0
      System.out.println("Setting sum to 0");
      countImpl.sum((int)0);

      // Calculate Start timelong startTime = System.currentTimeMillis();

      // Increment 1000 times
      System.out.println("Incrementing");
      for (int i = 0 ; i < 1000 ; i++ )
      { countImpl.increment();
      }

      // Calculate stop time; print out statisticslong stopTime = System.currentTimeMillis();
      System.out.println("Avg Ping = "
                       + ((stopTime - startTime)/1000f) + " msecs");
      System.out.println("Sum = " + countImpl.sum());
    } catch(Exception e)
    { System.err.println("System Exception");
      System.err.println(e);
    }
  }
}
