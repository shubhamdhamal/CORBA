// CountImpl.java: The Count Implementationclass CountImpl extends Counter.CountPOA
{
  privateint sum;

  // Constructors
  CountImpl(String name)
  { super();
    System.out.println("Count Object Created");
    sum = 0;
  }

  // get sumpublicint sum()
  { return sum;
  }

  // set sumpublicvoid sum(int val)
  { sum = val;
  }

  // increment methodpublicint increment()
  { sum++;
    return sum;
  }
}

