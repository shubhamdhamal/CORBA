// ComplexNumberImpl.java

import Ex3Module.ComplexNumberPOA ;

class ComplexNumberImpl extends ComplexNumberPOA
{
    long FirstReal , FirstImaginary ;
    long SecondReal , SecondImaginary ;
    long SumReal , SumImaginary ;

    public void setFirstNumber(long real , long imaginary)
    {
        FirstReal = real ;
        FirstImaginary = imaginary ;
    }

    public void setSecondNumber(long real , long imaginary)
    {
        SecondReal = real ;
        SecondImaginary = imaginary ;
    }    

    public void doSum()
    {
        SumReal = FirstReal + SecondReal ;
        SumImaginary = FirstImaginary + SecondImaginary ;
    }

    public long getReal()
    {
        return SumReal ;
    }
    
    public long getImaginary()
    {
        return SumImaginary ;
    }
}
