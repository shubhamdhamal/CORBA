// ComplexNumberClient.java

import Ex3Module.* ;
import org.omg.CosNaming.*;
import org.omg.CosNaming.NamingContextPackage.*;
import org.omg.CORBA.*;

class ComplexNumberClient
{
    public static void main(String [] args)    
    {
        ComplexNumber cNumber = null ;

        try
        {
            org.omg.CORBA.ORB orb = org.omg.CORBA.ORB.init(args,null);

            org.omg.CORBA.Object objRef = orb.resolve_initial_references("NameService");
            NamingContextExt ncRef = NamingContextExtHelper.narrow(objRef);    
            
            String name = "ComplexNumber" ;

            cNumber = ComplexNumberHelper.narrow(ncRef.resolve_str(name));

            cNumber.setFirstNumber(9 , 4) ;
            cNumber.setSecondNumber(8 , 2) ;
            cNumber.doSum() ;

            System.out.println("The sum of two complexnumber is : " + cNumber.getReal() + " + " + cNumber.getImaginary() + "i") ;

                    
        }
        catch(Exception e)
        {
            e.printStackTrace() ;
        }
    }
}
