public interface RemoteHelloInterface 
extends java.rmi.Remote {
	public void message(String _message) throws java.rmi.RemoteException;    
}
