import java.rmi.Naming;
import java.rmi.RemoteException;

/**
  * Remote Method Invocation example, class
  * implements both client and server
  */

public class RemoteHello 
extends java.rmi.server.UnicastRemoteObject 
implements RemoteHelloInterface{

   /**
     * 'Hello World' Server constructor, 
     * takes server name as argument
     */

   public RemoteHello(String _name) throws RemoteException{
      try {
         System.out.println("Binding to registry");
		   Naming.rebind("//localhost/" + _name, this);
		}catch (Exception e) {
		   System.out.println("HelloImpl err: " + e.getMessage());
		   e.printStackTrace();		
      }
   }

   /**
     * Object started as server takes only server name as argument,
     * started as a client it takes host, server name and message
     */

   public static void main(String[] _args){
      try{
         if(_args.length == 1){
            System.out.println("Starting Hello server");
            RemoteHello _rh = new RemoteHello(_args[0]);

            System.out.println("Suspends this thread");
            java.lang.Object _s = new java.lang.Object();
            synchronized (_s) {
               _s.wait();
            }
         }
         /*
            Client implementation
         */
         
         else if(_args.length == 3){
            System.out.println("Calling remote interface");

            RemoteHelloInterface _rhi = (RemoteHelloInterface)
               Naming.lookup("//" + _args[0] + "/" + _args[1]);
            
            System.out.println("Sends message:" + _args[2]);
            _rhi.message(_args[2]); 
         }else{
            System.out.println( "Wrong number of arguments\n" + 
               "Server needs port\n" + 
               "Client needs host, object name and message" );
         }
      }catch(Exception _e){
         _e.printStackTrace();
      }
   }

   /**
     * Implemented Remote interface
     */

   public void message(String message) throws java.rmi.RemoteException{
      System.out.println("Message:" + message);
   }

}



