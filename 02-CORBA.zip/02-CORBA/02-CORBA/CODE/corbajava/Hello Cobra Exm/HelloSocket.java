import java.net.ServerSocket;
import java.net.Socket;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.BufferedReader;

import java.io.OutputStream;
import java.io.DataOutputStream;

/**
  * 'Hello World' TCP example. 
  * Implements both client and server
  */

public class HelloSocket{
   /**
     * Hello server implementation ( needs only receiving port )
     */
   public HelloSocket(int _port){
      try{
         System.out.println("Initializing TCP Hello server to port " + _port);
         ServerSocket _ss = new ServerSocket(_port);

         System.out.println("Waiting for connection");
         Socket _s = _ss.accept();

         System.out.println("Establishing reader for the connection");
         InputStream _is = _s.getInputStream();
         InputStreamReader _isr = new InputStreamReader(_is);
         BufferedReader _br = new BufferedReader(_isr);

         System.out.println("Reading line from the stream");
         String _m = _br.readLine();

         System.out.println("Message from the client:" + _m);

         System.out.println("Cleaning up");
         _s.close();
      }catch(Exception _e){
         _e.printStackTrace();
      }
   }
   /**
     * Hello client implementation ( needs host name and port )
     */
   public HelloSocket(String _host, int _port, String _message){
      try{
         System.out.println("Establishing connection to host:" + _host + " port:" + _port);
         Socket _s = new Socket(_host, _port);

         System.out.println("Establishing a writer for the socket");
         OutputStream _os = _s.getOutputStream();
         DataOutputStream _dos = new DataOutputStream(_os);

         System.out.println("Writing to the stream:" + _message);
         _dos.writeBytes(_message);

         System.out.println("Flushing the stream");
         _dos.flush();

         System.out.println("Cleaning up");
         _s.close();
      }catch(Exception _e){
         _e.printStackTrace();
      }
   }

   /**
     * To start the object as server give only port as parameter
     * To start the object as client give parameters:
     * Host Port Message
     */
   public static void main(String[] _args){
      try{
         if(_args.length == 1){
            System.out.println("Starting Hello server");
            new HelloSocket(Integer.parseInt(_args[0]));
         }else if(_args.length == 3){
            System.out.println("Starting Hello client");
            new HelloSocket(_args[0],
                            Integer.parseInt(_args[1]),
                            _args[2]);
         }else{
            System.out.println( "Wrong number of arguments\n" + 
               "Server needs port\n" + 
               "Client needs host, port and message" );
         }
      }catch(Exception _e){
         _e.printStackTrace();
      }
   }
}
